<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/5683a284-9192-48e0-8a5c-c612c28bcd41

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## V4.3 No-Lag Computation Runtime
See `V4_3_NO_LAG_COMPUTATION.md`. Heavy screens now use keep-alive mounting; Daily Generator uses a bounded versioned consensus cache and deferred cancellable recomputation; ML training remains worker-based. The design target is that navigation never waits for historical replay or retraining.
